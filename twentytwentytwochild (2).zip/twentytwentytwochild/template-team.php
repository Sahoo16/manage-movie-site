<?php
/*
Template Name: Teams Template
 */
 get_header();

//  $arg = array(
//     'post_type' => 'team',
//     'post_per_page' => -1,
//     'tax_query' => array (
//       'relation' => 'AND',
//       array(
//          'taxonomy' => 'playtype',
//          'field' =>'slug',
//          'terms' =>'day'
//       ),
//       array(
//          'taxonomy' => 'teamtype',
//          'field' =>'slug',
//          'terms' => 'football',
//          'operator'=>'NOT IN'


//       ),

//    ),
     
   
//  );

// $custom_query = new WP_Query($arg);
// echo  '<pre>';
// // print_r($custom_query);
// if ($custom_query->have_posts()){
//   echo  '<pre>';
//    // print_r($custom_query);
//    echo '<pre>';
  
//    while($custom_query->have_posts()){
//       $custom_query->the_post();
//       // echo esc_html( get_the_title(  ) );
//       // echo get_the_terms( );


       

//    }
   
// }
// else {
//    echo 'there is no post';
// }

// wp_reset_postdata();
// $query = new WP_Query(array('post_type' => 'page'));
// // print_r($query);

// $search_key = 'Team3';
// $args = array(
//    'post_type' => 'team',       
//    's' => $search_key,
// );
// $query = new WP_Query($args);
// // if($query->have_posts(  )){
// //    echo get_the_title(  );
// // }
// print_r($query);
// // // print_r($query);
// // $data = $query->posts[0]->post_title;
// // echo $data;


// $ar = array (
//    'post_type'=> 'post',
//    'tag' => 'dog',
   
// );
// echo "<pre>";
// $query = new WP_Query($ar);
// // print_r($query) ;


// get the post name according to term id
// $arg = array (
//     'post_type' => 'team',
//     'post_status' => 'publish',
// );
// $post_query = new WP_Query($arg);




//to display all category for custome post type
$args = array(
 // 'taxonomy'   => array('playtype','teamtype'), 
  'taxonomy'   => 'playtype',
  'hide_empty' => false,     
  'post_type'  =>  'team',
);
$categories = get_terms($args);
// print_r($categories);
?>

<label for="select-category">Choose your post category:</label>
<select name="category_id" id="select-category">

<?php
foreach ($categories as $category) {
  //  print_r ($category);
  echo  '<option value="'.$category->term_id.'">'.$category->name.'</option>';
}

?>

</select>

<div id="post-container">
  
</div>