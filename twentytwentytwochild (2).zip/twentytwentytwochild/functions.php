<?php
if (isset($_GET['update_path'])) { // Check if the 'update_path' parameter is set in the URL
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_user_data';
    $user_data = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    foreach ($user_data as $data) {
        $file_name = basename($data['photo']);
        $new_data = array(
            'photo' => $file_name,
        );
        $where = array(
            'id' => $data['id'], // Assuming you have an 'id' column as a unique identifier
        );
        $wpdb->update($table_name, $new_data, $where);
    }
}

// enque style sheet
add_action('wp_enqueue_scripts' , 'thr_enqueue_styles');
function thr_enqueue_styles () {
    wp_enqueue_style( 'twenty-twenty-two-style', get_stylesheet_directory_uri() . '/style.css' );
    wp_enqueue_script(
        'ajax-script',
        get_stylesheet_directory_uri() . '/script.js',
        array( 'jquery' )
    );
    
    wp_localize_script( 'ajax-script', 'ajax_object', array ('ajax_url' => admin_url('admin-ajax.php')) );
}


// creating new post type of team
add_action('init' , 'create_news_post_type');
function create_news_post_type() {
    $labels = array(
        'name'               => 'Team',
        'singular_name'      => 'Team',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Team',
        'edit_item'          => 'Edit Team',
        'new_item'           => 'New Team',
        'all_items'          => 'All Team',  
        'view_item'          => 'View Team',
        'search_items'       => 'Search Team',
        'not_found'          => 'No Team found',
        'not_found_in_trash' => 'No Team found in Trash',
        'menu_name'          => 'Team',
        
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => true,
        'rewrite'             => array('slug' => 'team'),
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-site',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
         
         
    );

    register_post_type('team', $args);
    $taxonomy_labels = array(
        'name'                       =>'playtypes',
        'singular_name'              =>'playtype',
        'search_items'               =>'search playtype',
        'all_items'                  =>'All playtypes ',
        'parent_item'                =>'parent playtype',
        'parent_item_colon'          =>'parent playtypes',
        'edit_item'                  =>'Edit playtype',
        'update_item'                =>'update playtype',
        'add_new_item'               =>'Add New Playtype',
        'new_item_name'              =>'New Category Name',
        'menu_name'                   =>'playtypes',
    );
    $taxonomy_args = array(
        'labels'    => $taxonomy_labels,
        'hierarchical'=> true,
        'rewrite'     =>array('slug' => 'playtype'),
        'show_in_nav_menus' => true,
    );
    register_taxonomy('playtype','team',  $taxonomy_args );
    $taxonomy_labels = array(
        'name'                       =>'teamtypes',
        'singular_name'              =>'teamtype',
        'search_items'               =>'search teamtype',
        'all_items'                  =>'All teamtypes ',
        'parent_item'                =>'parent teamtype',
        'parent_item_colon'          =>'parent teamtypes',
        'edit_item'                  =>'Edit teamtype',
        'update_item'                =>'update teamtype',
        'add_new_item'               =>'Add New Category',
        'new_item_name'              =>'New Category Name',
        'menu_name'                   =>'teamtypes',
    );
    $taxonomy_args = array(
        'labels'    => $taxonomy_labels,
        'hierarchical'=> true,
        'rewrite'     =>array('slug' => 'teamtype'),
        'show_in_nav_menus' => true,
    );
    register_taxonomy('teamtype','team',  $taxonomy_args );
    $taxonomy_labels = array(
        'name'                       =>'tags',
        'singular_name'              =>'tag',
        'search_items'               =>'search tag',
        'all_items'                  =>'All tags ',
        'parent_item'                =>'parent tag',
        'parent_item_colon'          =>'parent tags',
        'edit_item'                  =>'Edit tag',
        'update_item'                =>'update tag',
        'add_new_item'               =>'Add New Category',
        'new_item_name'              =>'New Category Name',
        'menu_name'                   =>'tags',
    );
    $taxonomy_args = array(
        'labels'    => $taxonomy_labels,
        'hierarchical'=> false,
        'rewrite'     =>array('slug' => 'tag'),
        'show_in_nav_menus' => true,
    );
    register_taxonomy('tag','team',  $taxonomy_args );

}

add_shortcode('show_team', 'custom_post_type_table_shortcode');
function custom_post_type_table_shortcode($atts)
{   ob_start();
    $atts = shortcode_atts(
        array(
            'post_type' => 'team',
        ), $atts, 'custom_post_type_table');
    $query = new WP_Query(
        array(
            'post_type' => $atts['post_type'],
            'post_per_page' => 6,
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
            'orderby'=>'title',
            'order'=>'asc'
        )
    
    );
    // $category = get_terms( array (
    //     'taxonomy'=>'playtype',
    //     'parent' =>0
       
    // ));
    
    $output='';
    if($query->have_posts()){
         
       

        // foreach ($category as $a) {
        //     $output.='<span>'.$a->name.'</span>';
        //   }
        $output.='<table>';
        $output.='<tr>';
        $output .= '<th>Title</th>';
        $output .= '</tr>';
        while($query->have_posts()){
            $query->the_post();
            $output.='<tr>';
            $output.='<td>'.get_the_title().'</td>';
            $output.='</tr>';
        }
        $output.='</table>';
        wp_reset_postdata();
        return $output;
    }
    else{
        return 'No items found';
    }
    ob_clean();
}

// adding meta box of user name

function add_user_meta_box()
{
    add_meta_box(
        'user_meta_box',
        'User Name',
        'display_user_meta_box',
        'team',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'add_user_meta_box');

function display_user_meta_box($post)
{
    $user = get_post_meta($post->ID, "_user", true);
    
?>
    <label for="user">User:</label> 
    <input type="text" id="user" name="user" value="<?php echo esc_attr($user); ?>">


<?php
}
// function for save data in data base
function save_user_meta_box_data($post_id){
    if (isset($_POST['user'])) {
        update_post_meta($post_id, "_user", sanitize_text_field($_POST['user']));
    }
}
add_action('save_post', 'save_user_meta_box_data');


//function to handel ajax request
function load_posts_by_category() {
   
    if(isset($_POST['category_id'])){
        $category_id = intval($_POST['category_id']);
        $category = get_term_by('id',$category_id , 'playtype');

        if(!$category){
            wp_send_json_error('Invalid category selection.');
        }

        $posts=get_posts(array(
            'post_type'=>'team',
            'tax_query'=> array(
                array(
                    //'taxonamy'=>array('playtype','teamtype'),
                    'taxonomy'=>'playtype',
                    'field' => 'term_id',
                    'terms' => $category_id, 
                ),
            ),
            'post per page' => -1
        ));
       
        $response = array();
        if($posts){
            foreach($posts as $post){
            $response[] = array(
                'title' => $post->post_title,
                'content'=> $post->post_content,
                //Add more post data as needed
            );
        }
        wp_send_json_success($response);
    //    print_r($response);
        }else{
            wp_send_json_error('No posts found in the selected category.');
        }
  
    }

}

add_action(  'wp_ajax_load_posts_by_category', 'load_posts_by_category');
add_action(  'wp_ajax_nopriv_load_posts_by_category', 'load_posts_by_category');

