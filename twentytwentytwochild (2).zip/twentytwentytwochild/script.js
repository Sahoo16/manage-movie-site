jQuery(document).ready(function ($) {
   
    $("#select-category").on("change", function () {
      var categoryID = $(this).val();
      $.ajax({
        type: "post",
        url: ajax_object.ajax_url,
        data: {
          action: "load_posts_by_category",
          category_id: categoryID,
        },
        // dataType: "datatype",
        success: function (response) {
          if (response.success) {
            var posts = response.data;
            console.log(posts.length);

            var postContent = "";
            if (posts.length > 0) {
              posts.forEach(function(post)  {
                postContent += '<div class="post">';
                postContent += "<h2>" + post.title + "</h2>";
                postContent += "<div>" + post.content + "</div>";
                postContent += "</div>";
                
              });
            } else {
              postContent = "<p>No post found in the selected category.</p>";
            }
            $("#post-container").html(postContent);
          } else {
            alert(response.data);
          }
        },
        error: function (errorThrown) {
          console.log(errorThrown);
        },
      });
    });
  });